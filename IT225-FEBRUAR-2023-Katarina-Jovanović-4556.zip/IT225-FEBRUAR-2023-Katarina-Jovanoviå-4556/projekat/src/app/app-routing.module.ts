import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormaComponent } from './forma/forma.component';
import { LoginComponent } from './login/login.component';
import { PostComponent } from './post/post.component';
import { SinglePostComponent } from './single-post/single-post.component';

const routes: Routes = [
  {path: '', redirectTo: 'login', pathMatch: 'full' },
  {path:'posts', component:PostComponent},
  {path:'posts/:id', component:SinglePostComponent},
  {path:'form', component:FormaComponent},
  {path:'login', component:LoginComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
