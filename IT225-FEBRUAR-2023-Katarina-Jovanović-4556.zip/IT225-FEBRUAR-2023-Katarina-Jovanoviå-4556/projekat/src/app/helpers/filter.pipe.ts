import { Pipe, PipeTransform } from '@angular/core';
import { Post } from '../models/post';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(items: any[], searchText: string): any[] {
    if(!items) return [];
    else if(!searchText)  items;
    searchText = searchText.toLowerCase();
    return items.filter((item:Post) =>{
      return (item.title).toLowerCase().includes(searchText)
    })
  }

}
