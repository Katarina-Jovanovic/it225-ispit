import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Post } from '../models/post';
import { PostService } from '../services/post.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.scss']
})
export class PostComponent implements OnInit {

  public postForm!: FormGroup;
  public posts!: Post[];
  @Input() searchText:any;

  constructor(private _postService: PostService){
    
    this._postService.getAll().subscribe((data) => {
      this.posts = data;
    })

    this.initForm();
  }
  ngOnInit(): void {
    this.searchText = "";
    this._postService.getAll().subscribe((data:Post[])=>
    this.posts = data)
  }


  public initForm(){
    this.postForm = new FormGroup({
      title: new FormControl('',[
        Validators.required
      ]),
      body : new FormControl('', [
        Validators.required
      ])
    });
  }

  public submitForm(){
    let id= this.postForm.get('id')!.value;
    let title = this.postForm.get('title')!.value;
    let userId = this.postForm.get('userId')!.value;
    let body = this.postForm.get('body')!.value;
    let post = new Post(id,userId,title,body);
    
    this.createPost(post);
  }

  public createPost(post: Post){
    this._postService.createPost(post).subscribe((data) => 
    this.posts?.unshift(data));
  }

  public getOneById(id: number){
    this._postService.getOneById(id).subscribe((data) => {
      alert((JSON.stringify(data)))
    });
  }

  public deletePost(id: number){
    this._postService.deletePost(id).subscribe((data) => {
      this._removePostFromList(id);
      alert("Post Obrisan");
  })
}


private _removePostFromList(id: any){
  let ind = this.posts.findIndex(post => post.id == id);
  this.posts.splice(ind,1);
}


}
