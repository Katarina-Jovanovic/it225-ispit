import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { Post } from '../models/post';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  private baseUrl="https://jsonplaceholder.typicode.com/posts";

  constructor(private _httpClient: HttpClient) { }

  public getAll(): Observable<Post[]>{
    return this._httpClient.get<Post[]>(this.baseUrl).pipe(
      map((data:any[]) => data.map((item :any)=> 
      this._createPostFromObject(item)))
    );
  }

    public getOneById(id: number): Observable<Post>{
      return this._httpClient.get(this.baseUrl+'/'+id).pipe(
        map((data:any) => this._createPostFromObject(data))
      )
      
        }
        public deletePost(id: number): Observable<Post>{
          return this._httpClient.delete(this.baseUrl+'/'+id).pipe(
            map((data: any) => this._createPostFromObject(data))
          )
        }
        public createPost(post: Post) : Observable<Post> {
          return this._httpClient.post(this.baseUrl, post).pipe(
            map((data:any) => this._createPostFromObject(data))
          );
        }

        public updatePost(id: number): Observable<Post>{
          return this._httpClient.patch(this.baseUrl,id).pipe(
            map((data:any)=>this._createPostFromObject(data))
          )
      
        }
        private _createPostFromObject(item: any): any {
          return new Post(item.id,item.userId, item.title, item.body)
        }

  }

