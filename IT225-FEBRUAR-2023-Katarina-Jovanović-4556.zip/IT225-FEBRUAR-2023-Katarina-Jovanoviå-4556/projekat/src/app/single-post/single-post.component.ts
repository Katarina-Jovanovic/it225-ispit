import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Post } from '../models/post';
import { PostService } from '../services/post.service';

@Component({
  selector: 'app-single-post',
  templateUrl: './single-post.component.html',
  styleUrls: ['./single-post.component.scss']
})
export class SinglePostComponent implements OnInit {

  public post :Post;
  constructor(private _postService:PostService, private _router:ActivatedRoute) { }

  ngOnInit(): void {
    this._router.params.subscribe(params => {
      let id =+ params['id'];
      this.getPost(id);
    })
  }

  public getPost(id :number){
    this._postService.getOneById(id).subscribe((data) =>
    this.post = data);
  }

  

}
